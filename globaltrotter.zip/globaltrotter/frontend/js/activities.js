const tripId = localStorage.getItem('tripId');
const activitiesContainer = document.getElementById('activitiesContainer');
const token = localStorage.getItem('token');

async function fetchActivities() {
  try {
    const res = await fetch(`http://localhost:5000/api/activities/${tripId}`, {
      headers: { 'Authorization': `Bearer ${token}` }
    });
    const activities = await res.json();
    activitiesContainer.innerHTML = '';
    activities.forEach(a => {
      const div = document.createElement('div');
      div.className = 'activity-card';
      div.innerHTML = `
        <h4>${a.name}</h4>
        <p>${a.description}</p>
        <button onclick="deleteActivity(${a.id})">Delete</button>
      `;
      activitiesContainer.appendChild(div);
    });
  } catch(err){ console.log(err); }
}

async function createActivity() {
  const name = prompt('Activity name:');
  const description = prompt('Description:');
  if(!name) return;

  try {
    await fetch('http://localhost:5000/api/activities', {
      method: 'POST',
      headers: {
        'Content-Type':'application/json',
        'Authorization': `Bearer ${token}`
      },
      body: JSON.stringify({tripId, name, description})
    });
    fetchActivities();
  } catch(err){ alert('Failed to create activity'); }
}

async function deleteActivity(id){
  if(!confirm('Delete this activity?')) return;
  try {
    await fetch(`http://localhost:5000/api/activities/${id}`, {
      method: 'DELETE',
      headers: { 'Authorization': `Bearer ${token}` }
    });
    fetchActivities();
  } catch(err){ alert('Failed to delete activity'); }
}

window.addEventListener('load', fetchActivities);
